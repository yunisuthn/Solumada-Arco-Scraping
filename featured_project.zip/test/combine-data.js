const { DATA_DIR, DATA_SPLITED_DIR } = require('../../config');
const {ScrappingModule} = require('./scrapping.module');

const scrapper = new ScrappingModule(DATA_DIR, DATA_SPLITED_DIR);

const pageCount = Number(process.argv[2]) || 467;
scrapper.combinePage(pageCount)