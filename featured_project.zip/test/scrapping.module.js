const puppeteer = require('puppeteer');
const fs = require('fs');
/**
 * Module For scrapping data using puppeteer
 */
module.exports.ScrappingModule = class ScrappingModule {
    constructor(dataDir, dataSplitedDir) {
        this.dataDir = dataDir;
        this.dataSplitedDir = dataSplitedDir;
    }

    async scrap(params) {
        const browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox']
        });
        const page = await browser.newPage();
        const pageDetails = await browser.newPage();

        await page.setRequestInterception(true);
        await pageDetails.setRequestInterception(true);
        // ignore images and fonts
        page.on('request', (request) => {
            if (['image', 'font', 'stylesheet'].indexOf(request.resourceType()) !== -1) {
                request.abort();
            } else {
                request.continue();
            }
        });
        pageDetails.on('request', (request) => {
            if (['image', 'font', 'stylesheet'].indexOf(request.resourceType()) !== -1) {
                request.abort();
            } else {
                request.continue();
            }
        });
        
        const minPage = params.from || 1;
        const maxPage = params.to || minPage + 1;
    
        for(let p = minPage; p < maxPage; p++) {
            await page.goto(`https://www.property24.com/for-sale/johannesburg/gauteng/100/p${p}`,  {waitUntil: 'domcontentloaded', timeout: 120000});
            const bannedClass = await page.$('.col-9 style'); 
            let styleContent = await bannedClass.evaluate(node => node.innerHTML)
            const bannedClasses = styleContent.split('\n').map(el => el.trim()).filter(el => el[0]=='.')
    
            /// Selects all p24_content cards
            const selectors = `.js_listingResultsContainer .js_resultTile:not(${bannedClasses.join(',')})`;
            let cards = await page.$$(selectors);
            console.log(cards.length);
            const houses = [];
            let i = 1;

            // lopping for cards element and scrap each link from card
            for(let card of cards) {
                const link = await card.$('a');
                const href = await link.evaluate(n => n.getAttribute('href'));
                
                await pageDetails.goto(`https://www.property24.com${href}`,  {waitUntil: 'domcontentloaded', timeout: 120000});
                const features = await this.extractFeatureFromPage(pageDetails);
                houses.push(features);
                console.log(`[ℹ] ${i++} / ${cards.length} cards on page ${p}/${maxPage}`)
            }

            // Saving data to json file
            console.log(`[🤖] Writing page ${p} / ${maxPage} content in : ${this.dataSplitedDir}/page-${p}.json`)
            fs.writeFileSync(`${this.dataSplitedDir}/page-${p}.json`, JSON.stringify(houses))
            console.log('[👍] Writing data done')
    
        }
        await browser.close();
    }

    async extractFeatureFromPage(page) {
        const features = {}
    
        const priceEl = await page.$('.p24_listingFeaturesWrapper .p24_price');
        features.price = await priceEl.evaluate(n => n.textContent);
    
        const overviewsRowsEl = await page.$$('.p24_propertyOverviewRow');
        for(let overviewEl of overviewsRowsEl) {
            const keyEl = await overviewEl.$('div:nth-child(1)');
            const key = await keyEl.evaluate(n => n.textContent.trim());
            const valueEl = await overviewEl.$('div:nth-child(2)');
            const value = await valueEl.evaluate(n => n.textContent.trim());
    
            features[key] = value;
        }
        return features;
    }

    async combinePage(pageNumber) {
        const bigJson = [];

        for(let i = 1; i < pageNumber; i++) {
            const houseData = await require(`${process.cwd()}/${this.dataSplitedDir}/page-${i}.json`);
            for(let data of houseData) {
                console.log('Treated data ', i, 'of', pageNumber)
                if (Object.keys(data).length > 1) {
                    bigJson.push(data);
                }
            }
        }
        fs.writeFileSync(`${this.dataDir}/house.json`, JSON.stringify(bigJson))
    }
}