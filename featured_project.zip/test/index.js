const { DATA_DIR, DATA_SPLITED_DIR } = require('../../config');
const {ScrappingModule} = require('./scrapping.module');

const scrapper = new ScrappingModule(DATA_DIR, DATA_SPLITED_DIR);

const from = Number(process.argv[2]) || 1;
const to = Number(process.argv[3]) || 2;
scrapper.scrap({from, to})